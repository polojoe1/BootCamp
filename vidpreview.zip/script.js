console.log("page loaded...");
var x=document.querySelector("#Video");
function playVid(element){
    
    x.play();
}
function stopVid(element){
    x.pause();
}